# ComidaRápida PU (bagu)

App de delivery em HTML/CSS/JS puro com Supabase e Leaflet. Abra o `index.html` por um servidor estático.

## Novidades desta versão
- **Configurações** (menu da conta, no celular e no computador): editar nome, telefone, e-mail e senha; escolher tema **Claro, Escuro ou Automático**; alterar o endereço de entrega.
- **Modo escuro** com botão rápido no cabeçalho. A escolha fica salva no aparelho e é aplicada antes da página aparecer, sem piscar.
- **Conta no computador**: antes o menu da conta só existia no menu inferior do celular.
- **Checkout**: duas colunas no computador; no celular, uma coluna com barra fixa "Confirmar Pedido" (antes ela nunca aparecia e a grade estourava a tela).
- **Busca** da página inicial voltou a funcionar (também encontra pelo nome da loja e ignora acentos).
- Menu inferior não cobre mais o carrinho; o carrinho ganhou fundo escurecido, e os mapas não ficam mais por cima do cabeçalho.
- `minha-loja.css` era uma cópia do `styles.css`; agora tem os estilos reais da tela Minha Loja (mapa, upload de imagens, cartão da loja).
- Grades de lojas e formulários que não tinham CSS agora se adaptam ao celular.
- Imagens do logo e das categorias reduzidas de 2048px para 256px/160px.
