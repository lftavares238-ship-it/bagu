'use strict';
/* ==========================================================================
   CONFIGURAÇÕES: conta (nome, telefone, e-mail), senha, aparência e endereço.
   O tema (claro/escuro/automático) é controlado por window.Theme (index.html).
   ========================================================================== */
ICON.gear = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;

const ROLE_LABEL = { owner: 'Lojista', admin: 'Administrador', user: 'Cliente' };

function maskPhone(el) {
  let v = String(el.value).replace(/\D/g, '').slice(0, 11);
  if (v.length > 10) v = v.replace(/^(\d{2})(\d{5})(\d{0,4}).*/, '($1) $2-$3');
  else if (v.length > 6) v = v.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, '($1) $2-$3');
  else if (v.length > 2) v = v.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
  el.value = v;
}

function SettingsView() {
  const pref = Theme.pref();
  const opt = (v, label, sub) => `<button type="button" class="theme-opt" role="radio" aria-checked="${pref === v}" data-theme-opt="${v}" onclick="Theme.set('${v}')">
      <div class="sw ${v}"></div><strong>${label}</strong><span class="small muted">${sub}</span></button>`;

  const account = session ? `
    <section class="set-card">
      <h3>Dados da conta</h3>
      <p class="small muted lead">Tipo de conta: ${esc(ROLE_LABEL[session.role] || 'Cliente')}</p>
      <form id="accForm" onsubmit="saveAccount(event)">
        <div class="grid-2">
          <div class="input-group"><label for="acc_name">Nome completo</label><input id="acc_name" name="name" required minlength="2" maxlength="80" autocomplete="name" value="${esc(session.full_name)}"></div>
          <div class="input-group"><label for="acc_phone">Telefone</label><input id="acc_phone" name="phone" inputmode="tel" autocomplete="tel" placeholder="(00) 00000-0000" oninput="maskPhone(this)" value="${esc(session.phone)}"></div>
        </div>
        <div class="input-group"><label for="acc_email">E-mail</label><input id="acc_email" name="email" type="email" required autocomplete="email" value="${esc(session.email)}">
          <p class="small muted hint">Se você trocar o e-mail, enviamos um link de confirmação para o novo endereço.</p></div>
        <button class="btn btn-primary" id="accSave">Salvar dados</button>
      </form>
    </section>` : `
    <section class="set-card">
      <h3>Sua conta</h3>
      <p class="small muted lead">Entre para editar nome, telefone, e-mail e senha.</p>
      <button class="btn btn-primary" onclick="openAuth()">Entrar ou criar conta</button>
    </section>`;

  const appearance = `
    <section class="set-card">
      <h3>Aparência</h3>
      <p class="small muted lead">Escolha o tema do app. A preferência fica salva neste aparelho.</p>
      <div class="theme-opts" role="radiogroup" aria-label="Tema do app">
        ${opt('light', 'Claro', 'Fundo claro')}${opt('dark', 'Escuro', 'Menos brilho')}${opt('auto', 'Automático', 'Igual ao aparelho')}
      </div>
    </section>`;

  const address = `
    <section class="set-card">
      <h3>Endereço de entrega</h3>
      <p class="small muted lead">Usado para calcular a taxa e o tempo de entrega.</p>
      <div class="set-row">
        <strong style="min-width:0; overflow-wrap:anywhere;">${state.location.confirmed ? esc(state.location.label) : 'Nenhum endereço definido'}</strong>
        <button class="btn btn-ghost btn-sm" onclick="openLocModal()">${state.location.confirmed ? 'Alterar' : 'Definir'}</button>
      </div>
    </section>`;

  const security = session ? `
    <section class="set-card">
      <h3>Alterar senha</h3>
      <p class="small muted lead">Use pelo menos 6 caracteres.</p>
      <form id="pwdForm" onsubmit="savePassword(event)">
        <div class="grid-2">
          <div class="input-group"><label for="pw1">Nova senha</label><input id="pw1" name="pw1" type="password" minlength="6" required autocomplete="new-password"></div>
          <div class="input-group"><label for="pw2">Confirmar nova senha</label><input id="pw2" name="pw2" type="password" minlength="6" required autocomplete="new-password"></div>
        </div>
        <button class="btn btn-primary" id="pwdSave">Atualizar senha</button>
      </form>
    </section>
    <button class="btn btn-ghost btn-block" style="color:var(--primary-ink);" onclick="supa.auth.signOut()">Sair da conta</button>` : '';

  return `<div class="settings">
    <div class="settings-head"><button class="btn btn-ghost btn-sm" onclick="navigate('home')">← Voltar</button><h1>Configurações</h1></div>
    ${account}${appearance}${address}${security}
  </div>`;
}

async function saveAccount(e) {
  e.preventDefault();
  if (!session) return;
  const f = new FormData(e.target);
  const name = String(f.get('name') || '').trim();
  const phone = String(f.get('phone') || '').trim();
  const email = String(f.get('email') || '').trim();
  if (name.length < 2) { toast('Informe seu nome completo.', 'error'); return; }
  if (phone && ![10, 11].includes(phone.replace(/\D/g, '').length)) { toast('Telefone inválido.', 'error'); return; }
  const btn = document.getElementById('accSave');
  btn.disabled = true; btn.textContent = 'Salvando...';
  try {
    const { data: { user }, error: uErr } = await supa.auth.getUser();
    if (uErr || !user) throw uErr || new Error('Sessão expirada. Entre novamente.');
    const attrs = { data: { ...(user.user_metadata || {}), full_name: name, phone } };
    const emailChanged = !!email && email.toLowerCase() !== String(user.email || '').toLowerCase();
    if (emailChanged) attrs.email = email;
    const { error } = await supa.auth.updateUser(attrs);
    if (error) throw error;
    const { error: pErr } = await supa.from('profiles').update({ full_name: name }).eq('id', session.id);
    session.full_name = name; session.phone = phone;
    if (pErr) toast('Dados salvos, mas o perfil não foi atualizado: ' + pErr.message, 'error');
    else toast(emailChanged ? 'Dados salvos! Confirme o novo e-mail pelo link que enviamos.' : 'Dados da conta atualizados!');
    render();
  } catch (err) {
    toast('Erro ao salvar: ' + (err.message || err), 'error');
    btn.disabled = false; btn.textContent = 'Salvar dados';
  }
}

async function savePassword(e) {
  e.preventDefault();
  const f = new FormData(e.target);
  const a = String(f.get('pw1') || ''), b = String(f.get('pw2') || '');
  if (a.length < 6) { toast('A senha precisa ter pelo menos 6 caracteres.', 'error'); return; }
  if (a !== b) { toast('As senhas não conferem.', 'error'); return; }
  const btn = document.getElementById('pwdSave');
  btn.disabled = true; btn.textContent = 'Atualizando...';
  try {
    const { error } = await supa.auth.updateUser({ password: a });
    if (error) throw error;
    e.target.reset();
    toast('Senha atualizada!');
  } catch (err) {
    toast('Erro ao atualizar a senha: ' + (err.message || err), 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Atualizar senha';
  }
}

/* Mantém os botões de tema da tela de configurações em sincronia */
document.addEventListener('themechange', () => {
  document.querySelectorAll('[data-theme-opt]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.themeOpt === Theme.pref())));
});

/* Esc fecha modal e carrinho */
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (document.getElementById('modalRoot').innerHTML.trim()) closeModal();
  else if (state.cartOpen) toggleCart();
});
